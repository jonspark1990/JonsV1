import { Router, Response } from 'express';
import { AuthenticatedRequest, requireAuth } from '../middleware/authMiddleware.js';
import { Database } from '../db/database.js';
import { PaymentOrchestrator } from '../services/PaymentOrchestrator.js';
import { ExportService } from '../services/ExportService.js';

export const paymentLinkRouter = Router();

// GET /api/payment-links
// GET /api/payment-links
paymentLinkRouter.get('/', requireAuth('read_only'), (req: AuthenticatedRequest, res: Response): void => {
  const { status, brandId, customerId, search, createdByAdminId, datePreset, startDate, endDate } = req.query;
  const isPrivileged = ['super_admin', 'admin', 'manager'].includes(req.adminUser!.role);
  let links = Database.getPaymentLinks();

  // 1. Role-based isolation: Team members (e.g. link_creator) ONLY see links created by themselves
  if (!isPrivileged) {
    links = links.filter((l) => l.createdByAdminId === req.adminUser!.id);
  } else if (createdByAdminId && typeof createdByAdminId === 'string' && createdByAdminId !== 'ALL') {
    // Admin & Managers can filter by a specific team member / creator
    links = links.filter((l) => l.createdByAdminId === createdByAdminId);
  }

  // 2. Date presets & custom range filtering
  const now = Date.now();
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayStart = today.getTime();
  const yesterdayStart = todayStart - 86400000;
  const yesterdayEnd = todayStart - 1;

  if (datePreset === 'today') {
    links = links.filter((l) => new Date(l.createdAt).getTime() >= todayStart);
  } else if (datePreset === 'yesterday') {
    links = links.filter((l) => {
      const t = new Date(l.createdAt).getTime();
      return t >= yesterdayStart && t <= yesterdayEnd;
    });
  } else if (datePreset === '7days') {
    links = links.filter((l) => new Date(l.createdAt).getTime() >= now - 7 * 86400000);
  } else if (datePreset === '30days') {
    links = links.filter((l) => new Date(l.createdAt).getTime() >= now - 30 * 86400000);
  } else if (startDate && typeof startDate === 'string') {
    const sTime = new Date(startDate).getTime();
    const eTime = endDate && typeof endDate === 'string' ? new Date(endDate).getTime() : now;
    links = links.filter((l) => {
      const t = new Date(l.createdAt).getTime();
      return t >= sTime && t <= eTime;
    });
  }

  if (status && typeof status === 'string' && status !== 'ALL') {
    links = links.filter((l) => l.status === status);
  }
  if (brandId && typeof brandId === 'string' && brandId !== 'ALL') {
    links = links.filter((l) => l.brandId === brandId);
  }
  if (customerId && typeof customerId === 'string') {
    links = links.filter((l) => l.customerId === customerId);
  }
  if (search && typeof search === 'string') {
    const q = search.toLowerCase();
    const customers = Database.getCustomers();
    links = links.filter((l) => {
      const cust = customers.find((c) => c.id === l.customerId);
      return (
        l.token.toLowerCase().includes(q) ||
        l.merchantOrderNo.toLowerCase().includes(q) ||
        (l.externalReference && l.externalReference.toLowerCase().includes(q)) ||
        (cust && cust.fullName.toLowerCase().includes(q))
      );
    });
  }

  const customers = Database.getCustomers();
  const brands = Database.getBrands();
  const gateways = Database.getGatewayAccounts();
  const admins = Database.getAdmins();

  const enriched = links.map((l) => {
    const customer = customers.find((c) => c.id === l.customerId);
    const brand = brands.find((b) => b.id === l.brandId);
    const gateway = gateways.find((g) => g.id === l.gatewayAccountId);
    const creator = admins.find((a) => a.id === l.createdByAdminId);
    const isExpired = new Date(l.expiresAt).getTime() < Date.now();

    return {
      ...l,
      customerName: customer?.fullName || 'N/A',
      customerMobile: customer?.mobile || 'N/A',
      customerEmail: customer?.email || 'N/A',
      brandName: brand?.name || 'N/A',
      brandSlug: brand?.slug || 'pay',
      brandLogo: brand?.logoUrl,
      gatewayName: gateway?.name || 'N/A',
      createdByName: creator?.name || creator?.username || 'Administrator',
      createdByUsername: creator?.username || 'admin',
      isExpired,
      publicUrl: `/${brand?.slug || 'pay'}/pay/${l.token}`,
    };
  });

  res.json({ success: true, links: enriched });
});

// GET /api/payment-links/:id
paymentLinkRouter.get('/:id', requireAuth('read_only'), (req: AuthenticatedRequest, res: Response): void => {
  const links = Database.getPaymentLinks();
  const link = links.find((l) => l.id === req.params.id || l.token === req.params.id);

  if (!link) {
    res.status(404).json({ success: false, error: 'Payment link not found.' });
    return;
  }

  const isPrivileged = ['super_admin', 'admin', 'manager'].includes(req.adminUser!.role);
  if (!isPrivileged && link.createdByAdminId !== req.adminUser!.id) {
    res.status(403).json({ success: false, error: 'Access denied. You can only view payment links created by you.' });
    return;
  }

  const customer = Database.getCustomers().find((c) => c.id === link.customerId);
  const brand = Database.getBrands().find((b) => b.id === link.brandId);
  const gateway = Database.getGatewayAccounts().find((g) => g.id === link.gatewayAccountId);
  const history = Database.getPaymentStatusHistory().filter((h) => h.paymentLinkId === link.id);
  const transactions = Database.getTransactions().filter((t) => t.paymentLinkId === link.id);
  const creator = Database.getAdmins().find((a) => a.id === link.createdByAdminId);

  res.json({
    success: true,
    link: {
      ...link,
      customer,
      brand,
      gateway,
      history,
      transactions,
      createdByName: creator?.name || creator?.username || 'Administrator',
      createdByUsername: creator?.username || 'admin',
      publicUrl: `/${brand?.slug || 'pay'}/pay/${link.token}`,
    },
  });
});

// POST /api/payment-links
paymentLinkRouter.post('/', requireAuth(['operator', 'link_creator']), (req: AuthenticatedRequest, res: Response): void => {
  const {
    customerId,
    customerName,
    customerMobile,
    customerEmail,
    panNumber,
    bankAccount,
    executiveName,
    loanOrderNumber,
    repaymentDate,
    brandId,
    gatewayAccountId,
    amount,
    description,
    externalReference,
    expiresInHours,
    ogTitle,
    ogDescription,
    ogImageUrl,
  } = req.body;

  const result = PaymentOrchestrator.createPaymentLink({
    customerId,
    customerName,
    customerMobile,
    customerEmail,
    panNumber,
    bankAccount,
    executiveName,
    loanOrderNumber,
    repaymentDate,
    brandId,
    gatewayAccountId,
    amount: parseFloat(amount),
    description,
    externalReference,
    expiresInHours: expiresInHours ? parseInt(expiresInHours, 10) : undefined,
    adminId: req.adminUser!.id,
    ogTitle,
    ogDescription,
    ogImageUrl,
  });

  if (!result.success || !result.link) {
    res.status(400).json({ success: false, error: result.error || 'Failed to generate payment link' });
    return;
  }

  const createdLink = result.link;
  const brand = Database.getBrands().find((b) => b.id === createdLink.brandId);
  const customer = Database.getCustomers().find((c) => c.id === createdLink.customerId);
  const enrichedLink = {
    ...createdLink,
    customerName: customer?.fullName || customerName || 'Customer',
    customerMobile: customer?.mobile || customerMobile || '',
    brandName: brand?.name || 'Loan Services',
    brandSlug: brand?.slug || 'pay',
    publicUrl: `/${brand?.slug || 'pay'}/pay/${createdLink.token}`,
  };

  res.status(201).json({ success: true, link: enrichedLink });
});

// PUT /api/payment-links/:id
paymentLinkRouter.put('/:id', requireAuth(['operator', 'link_creator']), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const isPrivileged = ['super_admin', 'admin', 'manager'].includes(req.adminUser!.role);
  const {
    amount,
    description,
    loanOrderNumber,
    repaymentDate,
    panNumber,
    bankAccount,
    executiveName,
    externalReference,
    ogTitle,
    ogDescription,
    ogImageUrl,
  } = req.body;

  const links = Database.getPaymentLinks();
  const link = links.find((l) => l.id === id || l.token === id);

  if (!link) {
    res.status(404).json({ success: false, error: 'Payment link not found.' });
    return;
  }

  if (!isPrivileged && link.createdByAdminId !== req.adminUser!.id) {
    res.status(403).json({ success: false, error: 'Access denied. You can only edit payment links created by you.' });
    return;
  }

  if (amount !== undefined && !isNaN(parseFloat(amount)) && parseFloat(amount) > 0) {
    link.amount = Math.round(parseFloat(amount) * 100) / 100;
    link.amountFormatted = link.amount.toFixed(2);
  }
  if (description !== undefined) link.description = description.trim();
  if (loanOrderNumber !== undefined) link.loanOrderNumber = loanOrderNumber.trim();
  if (repaymentDate !== undefined) link.repaymentDate = repaymentDate.trim();
  if (panNumber !== undefined) link.panNumber = panNumber.trim();
  if (bankAccount !== undefined) link.bankAccount = bankAccount.trim();
  if (executiveName !== undefined) link.executiveName = executiveName.trim();
  if (externalReference !== undefined) link.externalReference = externalReference.trim();
  if (ogTitle !== undefined) link.ogTitle = ogTitle?.trim() || undefined;
  if (ogDescription !== undefined) link.ogDescription = ogDescription?.trim() || undefined;
  if (ogImageUrl !== undefined) link.ogImageUrl = ogImageUrl?.trim() || undefined;
  link.updatedAt = new Date().toISOString();

  Database.savePaymentLinks(links);

  Database.appendAuditLog({
    adminId: req.adminUser!.id,
    adminUsername: req.adminUser!.username,
    action: 'PAYMENT_LINK_UPDATED',
    entityType: 'PAYMENT_LINK',
    entityId: link.id,
    details: `Updated payment link ${link.token} details and WhatsApp social preview`,
  });

  const brand = Database.getBrands().find((b) => b.id === link.brandId);
  const customer = Database.getCustomers().find((c) => c.id === link.customerId);
  const creator = Database.getAdmins().find((a) => a.id === link.createdByAdminId);

  res.json({
    success: true,
    link: {
      ...link,
      customerName: customer?.fullName || 'Customer',
      customerMobile: customer?.mobile || '',
      brandName: brand?.name || 'Loan Services',
      brandSlug: brand?.slug || 'pay',
      createdByName: creator?.name || creator?.username || 'Administrator',
      createdByUsername: creator?.username || 'admin',
      publicUrl: `/${brand?.slug || 'pay'}/pay/${link.token}`,
    },
  });
});

// DELETE /api/payment-links/:id
paymentLinkRouter.delete('/:id', requireAuth(['operator', 'link_creator']), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const isPrivileged = ['super_admin', 'admin', 'manager'].includes(req.adminUser!.role);
  const links = Database.getPaymentLinks();
  const existing = links.find((l) => l.id === id || l.token === id);

  if (!existing) {
    res.status(404).json({ success: false, error: 'Payment link not found.' });
    return;
  }

  if (!isPrivileged && existing.createdByAdminId !== req.adminUser!.id) {
    res.status(403).json({ success: false, error: 'Access denied. You can only delete payment links created by you.' });
    return;
  }

  const filtered = links.filter((l) => l.id !== existing.id);
  Database.savePaymentLinks(filtered);

  Database.appendAuditLog({
    adminId: req.adminUser!.id,
    adminUsername: req.adminUser!.username,
    action: 'PAYMENT_LINK_DELETED',
    entityType: 'PAYMENT_LINK',
    entityId: existing.id,
    details: `Deleted payment link ${existing.token} (${existing.merchantOrderNo})`,
  });

  res.json({ success: true, message: 'Payment link deleted successfully.' });
});

// POST /api/payment-links/bulk-delete
paymentLinkRouter.post('/bulk-delete', requireAuth(['operator', 'link_creator']), (req: AuthenticatedRequest, res: Response): void => {
  const { ids } = req.body;
  if (!Array.isArray(ids) || ids.length === 0) {
    res.status(400).json({ success: false, error: 'Array of link IDs is required.' });
    return;
  }

  const isPrivileged = ['super_admin', 'admin', 'manager'].includes(req.adminUser!.role);
  const idSet = new Set(ids);
  const links = Database.getPaymentLinks();

  // If not privileged, prevent deleting links that do not belong to current user
  const targetLinks = links.filter((l) => idSet.has(l.id) || idSet.has(l.token));
  if (!isPrivileged) {
    const hasOtherLinks = targetLinks.some((l) => l.createdByAdminId !== req.adminUser!.id);
    if (hasOtherLinks) {
      res.status(403).json({ success: false, error: 'Access denied. You can only bulk delete links you created.' });
      return;
    }
  }

  const filtered = links.filter((l) => !idSet.has(l.id) && !idSet.has(l.token));
  const deletedCount = links.length - filtered.length;

  Database.savePaymentLinks(filtered);

  Database.appendAuditLog({
    adminId: req.adminUser!.id,
    adminUsername: req.adminUser!.username,
    action: 'PAYMENT_LINK_BULK_DELETED',
    entityType: 'PAYMENT_LINK',
    details: `Bulk deleted ${deletedCount} payment links`,
  });

  res.json({ success: true, deletedCount, message: `Successfully deleted ${deletedCount} link(s).` });
});

// PATCH /api/payment-links/:id/toggle
paymentLinkRouter.patch('/:id/toggle', requireAuth('operator'), (req: AuthenticatedRequest, res: Response): void => {
  const isPrivileged = ['super_admin', 'admin', 'manager'].includes(req.adminUser!.role);
  const links = Database.getPaymentLinks();
  const link = links.find((l) => l.id === req.params.id);

  if (!link) {
    res.status(404).json({ success: false, error: 'Payment link not found.' });
    return;
  }

  if (!isPrivileged && link.createdByAdminId !== req.adminUser!.id) {
    res.status(403).json({ success: false, error: 'Access denied. You can only toggle payment links created by you.' });
    return;
  }

  link.isEnabled = !link.isEnabled;
  link.updatedAt = new Date().toISOString();
  Database.savePaymentLinks(links);

  Database.appendAuditLog({
    adminId: req.adminUser!.id,
    adminUsername: req.adminUser!.username,
    action: link.isEnabled ? 'PAYMENT_LINK_ENABLED' : 'PAYMENT_LINK_DISABLED',
    entityType: 'PAYMENT_LINK',
    entityId: link.id,
    details: `${link.isEnabled ? 'Enabled' : 'Disabled'} payment link ${link.token}`,
  });

  res.json({ success: true, isEnabled: link.isEnabled });
});

// POST /api/payment-links/:id/recheck
paymentLinkRouter.post('/:id/recheck', requireAuth('operator'), async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const result = await PaymentOrchestrator.queryAndUpdateStatus(req.params.id, req.adminUser!.username);
  res.json(result);
});

// GET /api/payment-links/:id/tracking
paymentLinkRouter.get('/:id/tracking', requireAuth('read_only'), (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const isPrivileged = ['super_admin', 'admin', 'manager'].includes(req.adminUser!.role);
  const links = Database.getPaymentLinks();
  const link = links.find((l) => l.id === id || l.token === id);

  if (!link) {
    res.status(404).json({ success: false, error: 'Payment link not found.' });
    return;
  }

  if (!isPrivileged && link.createdByAdminId !== req.adminUser!.id) {
    res.status(403).json({ success: false, error: 'Access denied. You can only view tracking for links created by you.' });
    return;
  }

  const account = Database.getGatewayAccounts().find((a) => a.id === link.gatewayAccountId);

  res.json({
    success: true,
    tracking: {
      linkId: link.id,
      token: link.token,
      merchantOrderNo: link.merchantOrderNo,
      status: link.status,
      amountFormatted: link.amountFormatted,
      viewCount: link.viewCount || 0,
      lastViewedAt: link.lastViewedAt || null,
      clickCount: link.clickCount || 0,
      lastClickedAt: link.lastClickedAt || null,
      gatewayOrderNo: link.gatewayOrderNo || link.currentGatewayMchOrderNo || null,
      gatewayAdapter: account?.adapter || 'eaglepay',
      visitorEvents: link.visitorEvents || [],
      orderAttempts: link.orderAttempts || [],
    },
  });
});

// GET /api/payment-links/export/csv
paymentLinkRouter.get('/export/csv', requireAuth('read_only'), (req: AuthenticatedRequest, res: Response): void => {
  const links = Database.getPaymentLinks();
  const customers = Database.getCustomers();
  const brands = Database.getBrands();

  const rows = links.map((l) => {
    const cust = customers.find((c) => c.id === l.customerId);
    const brand = brands.find((b) => b.id === l.brandId);
    return {
      token: l.token,
      merchantOrderNo: l.merchantOrderNo,
      customer: cust?.fullName || '',
      mobile: cust?.mobile || '',
      brand: brand?.name || '',
      amount: l.amountFormatted,
      currency: l.currency,
      status: l.status,
      isEnabled: l.isEnabled ? 'Yes' : 'No',
      createdAt: l.createdAt,
      expiresAt: l.expiresAt,
      paidAt: l.paidAt || '',
    };
  });

  const csv = ExportService.toCsv(rows, [
    { key: 'token', label: 'Link Token' },
    { key: 'merchantOrderNo', label: 'Merchant Order No' },
    { key: 'customer', label: 'Customer Name' },
    { key: 'mobile', label: 'Customer Mobile' },
    { key: 'brand', label: 'Brand' },
    { key: 'amount', label: 'Amount (INR)' },
    { key: 'currency', label: 'Currency' },
    { key: 'status', label: 'Status' },
    { key: 'isEnabled', label: 'Enabled' },
    { key: 'createdAt', label: 'Created At' },
    { key: 'expiresAt', label: 'Expires At' },
    { key: 'paidAt', label: 'Paid At' },
  ]);

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="payment_links_export.csv"');
  res.send(csv);
});
